import 'dart:io' show File;

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

import '../models/child_model.dart';
import '../theme/app_theme.dart';
import '../widgets/app_page_scaffold.dart';
import 'video_preview_page.dart';

class ParentUpdatesPage extends StatefulWidget {
  final ChildModel child;

  const ParentUpdatesPage({
    super.key,
    required this.child,
  });

  @override
  State<ParentUpdatesPage> createState() => _ParentUpdatesPageState();
}

class _ParentUpdatesPageState extends State<ParentUpdatesPage> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  DateTime? _selectedDate;
  int _visibleDayCount = 2;

  Future<void> _refreshPage() async {
    if (!mounted) return;
    setState(() {});
  }

  Future<void> _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate ?? DateTime.now(),
      firstDate: DateTime(2020),
      lastDate: DateTime.now().add(const Duration(days: 365)),
      helpText: 'اختيار التاريخ',
      cancelText: 'إلغاء',
      confirmText: 'اختيار',
    );

    if (picked == null || !mounted) return;

    setState(() {
      _selectedDate = DateTime(picked.year, picked.month, picked.day);
    });
  }

  DateTime? _dateFromTimestamp(Timestamp? timestamp) {
    if (timestamp == null) return null;
    final value = timestamp.toDate();
    return DateTime(value.year, value.month, value.day);
  }

  bool _isSameDay(DateTime a, DateTime b) {
    return a.year == b.year && a.month == b.month && a.day == b.day;
  }

  String _dateTitle(DateTime? date) {
    if (date == null) return 'بدون تاريخ';

    final today = DateTime.now();
    final todayOnly = DateTime(today.year, today.month, today.day);
    final yesterdayOnly = todayOnly.subtract(const Duration(days: 1));

    if (_isSameDay(date, todayOnly)) return 'اليوم';
    if (_isSameDay(date, yesterdayOnly)) return 'أمس';

    final y = date.year.toString();
    final m = date.month.toString().padLeft(2, '0');
    final d = date.day.toString().padLeft(2, '0');
    return '$y/$m/$d';
  }

  List<MapEntry<DateTime?, List<Map<String, dynamic>>>> _groupUpdatesByDate(
    List<Map<String, dynamic>> updates,
  ) {
    final grouped = <String, List<Map<String, dynamic>>>{};
    final dates = <String, DateTime?>{};

    for (final update in updates) {
      final date = _dateFromTimestamp(update['displayTime'] as Timestamp?);
      final key = date == null
          ? 'no_date'
          : '${date.year}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}';

      grouped.putIfAbsent(key, () => []).add(update);
      dates[key] = date;
    }

    final entries = grouped.entries.map((entry) {
      return MapEntry(dates[entry.key], entry.value);
    }).toList();

    entries.sort((a, b) {
      if (a.key == null && b.key == null) return 0;
      if (a.key == null) return 1;
      if (b.key == null) return -1;
      return b.key!.compareTo(a.key!);
    });

    return entries;
  }

  String sectionLabel(String section) {
    if (section.trim() == 'Nursery') return 'حضانة';
    return section.trim().isEmpty ? 'حضانة' : section;
  }

  Color sectionColor(String section) {
    return const Color(0xFFEFA7C8);
  }

  String senderLabel(String byRole) {
    final role = byRole.trim().toLowerCase();

    if (role == 'nursery' ||
        role == 'nursery_staff' ||
        role == 'nursery staff') {
      return 'موظفة الحضانة';
    }

    if (role == 'admin') return 'الإدارة';
    if (role == 'parent') return 'ولي الأمر';

    return byRole.trim().isEmpty ? 'غير محدد' : byRole;
  }

  Color typeColor(String type) {
    switch (type.trim()) {
      case 'group_update':
        return Colors.purple;
      case 'تحديث جماعي':
        return Colors.purple;
      case 'وجبة':
        return Colors.orange;
      case 'نوم':
        return Colors.indigo;
      case 'حفاض':
        return Colors.brown;
      case 'صحة':
        return Colors.redAccent;
      case 'نشاط':
        return Colors.green;
      case 'ملاحظة':
        return AppColors.textLight;
      case 'وسائط':
      case 'كاميرا':
        return Colors.pink;
      default:
        return AppColors.primary;
    }
  }

  IconData typeIcon(String type) {
    switch (type.trim()) {
      case 'group_update':
        return Icons.groups_2_rounded;
      case 'تحديث جماعي':
        return Icons.groups_2_rounded;
      case 'وجبة':
        return Icons.restaurant_outlined;
      case 'نوم':
        return Icons.bedtime_outlined;
      case 'حفاض':
        return Icons.child_care_outlined;
      case 'صحة':
        return Icons.health_and_safety_outlined;
      case 'نشاط':
        return Icons.toys_outlined;
      case 'ملاحظة':
        return Icons.edit_note_outlined;
      case 'وسائط':
      case 'كاميرا':
        return Icons.photo_library_outlined;
      default:
        return Icons.notifications_none;
    }
  }

  String timeText(Timestamp? timestamp) {
    if (timestamp == null) return '--:--';

    final t = timestamp.toDate();
    final h = t.hour.toString().padLeft(2, '0');
    final m = t.minute.toString().padLeft(2, '0');

    return '$h:$m';
  }

  String dateText(Timestamp? timestamp) {
    if (timestamp == null) return '--/--/----';

    final t = timestamp.toDate();
    final y = t.year.toString();
    final m = t.month.toString().padLeft(2, '0');
    final d = t.day.toString().padLeft(2, '0');

    return '$y/$m/$d';
  }

  String firstLetter(String name) {
    if (name.trim().isEmpty) return 'ط';
    return name.trim().substring(0, 1);
  }

  String childAgeText(DateTime? birthDate) {
    if (birthDate == null) return 'غير محدد';

    final now = DateTime.now();

    int years = now.year - birthDate.year;
    int months = now.month - birthDate.month;

    if (now.day < birthDate.day) {
      months--;
    }

    if (months < 0) {
      years--;
      months += 12;
    }

    if (years <= 0) {
      return '$months شهر';
    }

    if (months == 0) {
      return '$years سنة';
    }

    return '$years سنة و $months شهر';
  }

  String _firstNonEmpty(List<dynamic> values) {
    for (final value in values) {
      if (value != null && value.toString().trim().isNotEmpty) {
        return value.toString().trim();
      }
    }

    return '';
  }

  String _resolveType(Map<String, dynamic> data) {
    final candidates = [
      data['type'],
      data['updateType'],
      data['category'],
      data['title'],
    ];

    for (final value in candidates) {
      if (value != null && value.toString().trim().isNotEmpty) {
        return value.toString().trim();
      }
    }

    return 'تحديث';
  }

  String _resolveNote(Map<String, dynamic> data) {
    final candidates = [
      data['note'],
      data['message'],
      data['body'],
      data['description'],
      data['details'],
    ];

    for (final value in candidates) {
      if (value != null && value.toString().trim().isNotEmpty) {
        return value.toString().trim();
      }
    }

    return '';
  }

  String _resolveRole(Map<String, dynamic> data) {
    final candidates = [
      data['byRole'],
      data['createdByRole'],
      data['senderRole'],
      data['role'],
    ];

    for (final value in candidates) {
      if (value != null && value.toString().trim().isNotEmpty) {
        return value.toString().trim();
      }
    }

    return '';
  }

  String _resolveCreatorName(Map<String, dynamic> data) {
    final candidates = [
      data['createdByName'],
      data['senderName'],
      data['byName'],
      data['staffName'],
    ];

    for (final value in candidates) {
      if (value != null && value.toString().trim().isNotEmpty) {
        return value.toString().trim();
      }
    }

    return '';
  }

  Timestamp? _resolveTimestamp(Map<String, dynamic> data) {
    final candidates = [
      data['eventAt'],
      data['time'],
      data['createdAt'],
      data['timestamp'],
      data['updatedAt'],
    ];

    for (final value in candidates) {
      if (value is Timestamp) return value;
    }

    return null;
  }

  bool _isGroupUpdate(Map<String, dynamic> data) {
    final type = (data['type'] ?? '').toString().trim().toLowerCase();
    final source = (data['source'] ?? '').toString().trim().toLowerCase();
    final updateSource =
        (data['updateSource'] ?? '').toString().trim().toLowerCase();

    return data['isGroupUpdate'] == true ||
        type == 'group_update' ||
        source == 'group_update' ||
        updateSource == 'group_update' ||
        data['groupUpdateId'] != null;
  }

  bool _isUsableRemoteUrl(String value) {
    final trimmed = value.trim().toLowerCase();
    return trimmed.startsWith('http://') || trimmed.startsWith('https://');
  }

  String _resolveMediaUrl(Map<String, dynamic> data) {
    final publicUrl = _firstNonEmpty([
      data['publicUrl'],
      data['mediaPublicUrl'],
    ]);

    if (_isUsableRemoteUrl(publicUrl)) {
      return publicUrl;
    }

    final directUrl = _firstNonEmpty([
      data['mediaUrl'],
      data['imageUrl'],
      data['videoUrl'],
      data['url'],
    ]);

    if (_isUsableRemoteUrl(directUrl)) {
      return directUrl;
    }

    final mediaUrls = data['mediaUrls'];

    if (mediaUrls is List && mediaUrls.isNotEmpty) {
      for (final item in mediaUrls) {
        final candidate = item?.toString().trim() ?? '';

        if (_isUsableRemoteUrl(candidate)) {
          return candidate;
        }
      }
    }

    return '';
  }

  String _resolveMediaPath(Map<String, dynamic> data) {
    final path = _firstNonEmpty([
      data['mediaPath'],
      data['path'],
      data['imagePath'],
      data['videoPath'],
    ]);

    if (path.startsWith('blob:')) {
      return '';
    }

    if (_isUsableRemoteUrl(path)) {
      return '';
    }

    return path;
  }

  String _resolvePublicUrl(Map<String, dynamic> data) {
    return _firstNonEmpty([
      data['publicUrl'],
      data['mediaPublicUrl'],
    ]);
  }

  String _resolveStorageProvider(Map<String, dynamic> data) {
    return _firstNonEmpty([
      data['storageProvider'],
      data['provider'],
    ]);
  }

  String _resolveMediaType(Map<String, dynamic> data) {
    final mediaType = (data['mediaType'] ?? '').toString().trim().toLowerCase();

    if (mediaType.isNotEmpty) {
      return mediaType;
    }

    final mediaUrl = _resolveMediaUrl(data).toLowerCase();
    final mediaPath = _resolveMediaPath(data).toLowerCase();
    final mimeType = (data['mimeType'] ?? '').toString().trim().toLowerCase();
    final source = '$mediaUrl $mediaPath $mimeType';

    if (source.endsWith('.mp4') ||
        source.endsWith('.mov') ||
        source.endsWith('.avi') ||
        source.endsWith('.mkv') ||
        source.endsWith('.webm') ||
        source.endsWith('.m4v') ||
        source.contains('video')) {
      return 'video';
    }

    if (source.endsWith('.jpg') ||
        source.endsWith('.jpeg') ||
        source.endsWith('.png') ||
        source.endsWith('.webp') ||
        source.endsWith('.gif') ||
        source.contains('image')) {
      return 'image';
    }

    return '';
  }

  Future<List<Map<String, dynamic>>> fetchUpdates() async {
    final snapshot = await _firestore
        .collection('updates')
        .where('childId', isEqualTo: widget.child.id)
        .get();

    final items = snapshot.docs.map((doc) {
      final data = doc.data();

      final mediaUrl = _resolveMediaUrl(data);
      final mediaPath = _resolveMediaPath(data);
      final mediaType = _resolveMediaType(data);
      final publicUrl = _resolvePublicUrl(data);
      final storageProvider = _resolveStorageProvider(data);

      final resolvedSource = publicUrl.isNotEmpty
          ? publicUrl
          : mediaUrl.isNotEmpty
              ? mediaUrl
              : mediaPath;

      final isGroupUpdate = _isGroupUpdate(data);
      final resolvedType = _resolveType(data);

      return {
        'id': doc.id,
        'type': isGroupUpdate && resolvedType == 'group_update'
            ? 'تحديث'
            : resolvedType,
        'note': _resolveNote(data),
        'byRole': _resolveRole(data),
        'createdByName': _resolveCreatorName(data),
        'displayTime': _resolveTimestamp(data),
        'mediaUrl': mediaUrl,
        'publicUrl': publicUrl,
        'storageProvider': storageProvider,
        'mediaType': mediaType,
        'mediaPath': mediaPath,
        'resolvedSource': resolvedSource,
        'hasMedia': resolvedSource.isNotEmpty && mediaType.isNotEmpty,
        'isGroupUpdate': isGroupUpdate,
        'groupUpdateId': data['groupUpdateId'],
        'groupId': data['groupId'],
        'groupName': data['groupName'],
        'updateScope': data['updateScope'] ?? data['scope'] ?? '',
      };
    }).toList();

    items.sort((a, b) {
      final aTime = a['displayTime'] as Timestamp?;
      final bTime = b['displayTime'] as Timestamp?;

      if (aTime == null && bTime == null) return 0;
      if (aTime == null) return 1;
      if (bTime == null) return -1;

      return bTime.compareTo(aTime);
    });

    return items;
  }

  @override
  Widget build(BuildContext context) {
    final child = widget.child;
    return AppPageScaffold(
      title: 'تحديثات الطفل',
      child: RefreshIndicator(
        onRefresh: _refreshPage,
        child: FutureBuilder<List<Map<String, dynamic>>>(
          future: fetchUpdates(),
          builder: (context, updatesSnapshot) {
            if (updatesSnapshot.connectionState == ConnectionState.waiting) {
              return const Center(
                child: CircularProgressIndicator(),
              );
            }

            if (updatesSnapshot.hasError) {
              return ListView(
                physics: const AlwaysScrollableScrollPhysics(),
                children: [
                  const SizedBox(height: 100),
                  Center(
                    child: Text(
                      'حدث خطأ أثناء تحميل التحديثات: ${updatesSnapshot.error}',
                      textAlign: TextAlign.center,
                    ),
                  ),
                ],
              );
            }

            final updates = updatesSnapshot.data ?? [];
            final visibleUpdates = _selectedDate == null
                ? updates
                : updates.where((update) {
                    final date = _dateFromTimestamp(
                      update['displayTime'] as Timestamp?,
                    );
                    return date != null && _isSameDay(date, _selectedDate!);
                  }).toList();
            final allGroupedUpdates = _groupUpdatesByDate(visibleUpdates);
            final groupedUpdates = _selectedDate == null
                ? allGroupedUpdates.take(_visibleDayCount).toList()
                : allGroupedUpdates;
            final hasMoreUpdates = _selectedDate == null &&
                allGroupedUpdates.length > groupedUpdates.length;

            return ListView(
              physics: const AlwaysScrollableScrollPhysics(),
              children: [
                Container(
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [AppColors.primary, AppColors.secondary],
                    ),
                    borderRadius: BorderRadius.circular(22),
                  ),
                  child: Row(
                    children: [
                      CircleAvatar(
                        radius: 30,
                        backgroundColor: Colors.white.withOpacity(0.18),
                        child: Text(
                          firstLetter(child.name),
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Text(
                          child.name,
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 20,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: _pickDate,
                        icon: const Icon(Icons.calendar_month_outlined),
                        label: Text(
                          _selectedDate == null
                              ? 'اختيار تاريخ'
                              : _dateTitle(_selectedDate),
                        ),
                        style: OutlinedButton.styleFrom(
                          minimumSize: const Size(double.infinity, 48),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(14),
                          ),
                        ),
                      ),
                    ),
                    if (_selectedDate != null) ...[
                      const SizedBox(width: 10),
                      IconButton.filledTonal(
                        onPressed: () {
                          setState(() {
                            _selectedDate = null;
                            _visibleDayCount = 2;
                          });
                        },
                        icon: const Icon(Icons.close_rounded),
                        tooltip: 'كل الأيام',
                      ),
                    ],
                  ],
                ),
                const SizedBox(height: 16),
                if (updates.isEmpty)
                  const Card(
                    child: Padding(
                      padding: EdgeInsets.all(20),
                      child: Center(
                        child: Text(
                          'لا توجد تحديثات',
                          style: TextStyle(
                            color: AppColors.textLight,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                  )
                else if (visibleUpdates.isEmpty)
                  const Card(
                    child: Padding(
                      padding: EdgeInsets.all(20),
                      child: Center(
                        child: Text(
                          'لا توجد تحديثات في هذا التاريخ',
                          style: TextStyle(
                            color: AppColors.textLight,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                  )
                else
                  ...groupedUpdates.map((entry) {
                    final groupDate = entry.key;
                    final groupItems = entry.value;

                    return Card(
                      margin: const EdgeInsets.only(bottom: 14),
                      child: Padding(
                        padding: const EdgeInsets.all(12),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            Text(
                              _dateTitle(groupDate),
                              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                                    color: AppColors.primary,
                                    fontWeight: FontWeight.bold,
                                  ),
                            ),
                            const SizedBox(height: 10),
                            ...groupItems.map((u) {
                              final Timestamp? displayTime =
                                  u['displayTime'] as Timestamp?;

                              return _UpdateCard(
                                type: (u['type'] ?? '').toString(),
                                note: (u['note'] ?? '').toString(),
                                senderText:
                                    senderLabel((u['byRole'] ?? '').toString()),
                                creatorName: (u['createdByName'] ?? '').toString(),
                                badgeColor: typeColor((u['type'] ?? '').toString()),
                                icon: typeIcon((u['type'] ?? '').toString()),
                                timeTextValue: timeText(displayTime),
                                dateTextValue: dateText(displayTime),
                                mediaUrl: u['mediaUrl']?.toString(),
                                publicUrl: u['publicUrl']?.toString(),
                                storageProvider: u['storageProvider']?.toString(),
                                mediaType: u['mediaType']?.toString(),
                                mediaPath: u['mediaPath']?.toString(),
                                hasMedia: u['hasMedia'] == true,
                                isGroupUpdate: u['isGroupUpdate'] == true,
                                groupName: (u['groupName'] ?? '').toString(),
                                updateScope: (u['updateScope'] ?? '').toString(),
                              );
                            }),
                          ],
                        ),
                      ),
                    );
                  }),
                if (hasMoreUpdates)
                  Padding(
                    padding: const EdgeInsets.only(top: 2, bottom: 12),
                    child: OutlinedButton.icon(
                      onPressed: () {
                        setState(() {
                          _visibleDayCount += 2;
                        });
                      },
                      icon: const Icon(Icons.expand_more_rounded),
                      label: const Text('عرض المزيد'),
                      style: OutlinedButton.styleFrom(
                        minimumSize: const Size(double.infinity, 48),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(14),
                        ),
                      ),
                    ),
                  ),
              ],
            );
          },
        ),
      ),
    );
  }
}

class _UpdateCard extends StatelessWidget {
  final String type;
  final String note;
  final String senderText;
  final String creatorName;
  final Color badgeColor;
  final IconData icon;
  final String timeTextValue;
  final String dateTextValue;
  final String? mediaUrl;
  final String? publicUrl;
  final String? storageProvider;
  final String? mediaType;
  final String? mediaPath;
  final bool hasMedia;
  final bool isGroupUpdate;
  final String groupName;
  final String updateScope;

  const _UpdateCard({
    required this.type,
    required this.note,
    required this.senderText,
    required this.creatorName,
    required this.badgeColor,
    required this.icon,
    required this.timeTextValue,
    required this.dateTextValue,
    this.mediaUrl,
    this.publicUrl,
    this.storageProvider,
    this.mediaType,
    this.mediaPath,
    required this.hasMedia,
    required this.isGroupUpdate,
    required this.groupName,
    required this.updateScope,
  });

  bool get _hasRemoteUrl {
    final value = (mediaUrl ?? '').trim().toLowerCase();
    return value.startsWith('http://') || value.startsWith('https://');
  }

  bool get _hasPublicUrl {
    final value = (publicUrl ?? '').trim().toLowerCase();
    return value.startsWith('http://') || value.startsWith('https://');
  }

  String get _bestRemoteUrl {
    if (_hasPublicUrl) return publicUrl!.trim();
    if (_hasRemoteUrl) return mediaUrl!.trim();
    return '';
  }

  bool get _hasLocalPath {
    final value = (mediaPath ?? '').trim();

    if (value.isEmpty) return false;
    if (value.startsWith('blob:')) return false;

    return true;
  }

  String get _normalizedMediaType => (mediaType ?? '').trim().toLowerCase();

  String get _resolvedSource {
    if (_hasPublicUrl) return publicUrl!.trim();
    if (_hasRemoteUrl) return mediaUrl!.trim();
    if (_hasLocalPath) return mediaPath!.trim();
    return '';
  }

  bool get _hasRemoteVideo =>
      (_hasPublicUrl || _hasRemoteUrl) && _normalizedMediaType == 'video';

  bool get _hasLocalImage =>
      !kIsWeb && _hasLocalPath && _normalizedMediaType == 'image';

  bool get _hasLocalVideo =>
      !kIsWeb && _hasLocalPath && _normalizedMediaType == 'video';

  String get _senderDisplay {
    if (creatorName.trim().isNotEmpty) {
      return '$creatorName - $senderText';
    }

    return senderText;
  }

  @override
  Widget build(BuildContext context) {
    final displayType = type.trim().isEmpty ? 'تحديث' : type;

    return Card(
      color: isGroupUpdate ? Colors.purple.withOpacity(0.035) : null,
      shape: isGroupUpdate
          ? RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(18),
              side: BorderSide(
                color: Colors.purple.withOpacity(0.20),
              ),
            )
          : null,
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(
                  backgroundColor: badgeColor.withOpacity(0.14),
                  child: Icon(
                    icon,
                    color: badgeColor,
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 10,
                          vertical: 6,
                        ),
                        decoration: BoxDecoration(
                          color: badgeColor.withOpacity(0.14),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Text(
                          displayType,
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: badgeColor,
                          ),
                        ),
                      ),
                      if (isGroupUpdate)
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 10,
                            vertical: 6,
                          ),
                          decoration: BoxDecoration(
                            color: Colors.purple.withOpacity(0.12),
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(
                              color: Colors.purple.withOpacity(0.25),
                            ),
                          ),
                          child: const Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(
                                Icons.groups_2_rounded,
                                size: 16,
                                color: Colors.purple,
                              ),
                              SizedBox(width: 5),
                              Text(
                                'تحديث جماعي',
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  color: Colors.purple,
                                ),
                              ),
                            ],
                          ),
                        ),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 10,
                          vertical: 6,
                        ),
                        decoration: BoxDecoration(
                          color: AppColors.primary.withOpacity(0.12),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Text(
                          timeTextValue,
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      if (hasMedia)
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 10,
                            vertical: 6,
                          ),
                          decoration: BoxDecoration(
                            color: Colors.purple.withOpacity(0.10),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Text(
                            _normalizedMediaType == 'video' ? 'فيديو' : 'صورة',
                            style: const TextStyle(
                              fontWeight: FontWeight.bold,
                              color: Colors.purple,
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            if (note.trim().isNotEmpty)
              Text(
                note,
                style: const TextStyle(
                  fontSize: 15,
                  height: 1.5,
                  color: AppColors.textDark,
                ),
              ),
            if (isGroupUpdate &&
                (groupName.trim().isNotEmpty ||
                    updateScope.trim().isNotEmpty)) ...[
              const SizedBox(height: 10),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  if (groupName.trim().isNotEmpty)
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 10,
                        vertical: 6,
                      ),
                      decoration: BoxDecoration(
                        color: Colors.purple.withOpacity(0.08),
                        borderRadius: BorderRadius.circular(999),
                        border: Border.all(
                          color: Colors.purple.withOpacity(0.18),
                        ),
                      ),
                      child: Text(
                        'المجموعة: $groupName',
                        style: const TextStyle(
                          color: Colors.purple,
                          fontWeight: FontWeight.w700,
                          fontSize: 12.5,
                        ),
                      ),
                    ),
                  if (updateScope.trim().isNotEmpty)
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 10,
                        vertical: 6,
                      ),
                      decoration: BoxDecoration(
                        color: Colors.purple.withOpacity(0.08),
                        borderRadius: BorderRadius.circular(999),
                        border: Border.all(
                          color: Colors.purple.withOpacity(0.18),
                        ),
                      ),
                      child: Text(
                        updateScope.trim() == 'all'
                            ? 'النطاق: كل أطفال الحضانة'
                            : updateScope.trim() == 'group'
                                ? 'النطاق: مجموعة محددة'
                                : 'النطاق: ${updateScope.trim()}',
                        style: const TextStyle(
                          color: Colors.purple,
                          fontWeight: FontWeight.w700,
                          fontSize: 12.5,
                        ),
                      ),
                    ),
                ],
              ),
            ],
            const SizedBox(height: 10),
            Row(
              children: [
                const Icon(
                  Icons.person_outline,
                  size: 18,
                  color: Colors.black54,
                ),
                const SizedBox(width: 6),
                Expanded(
                  child: Text(
                    'بواسطة: $_senderDisplay',
                    style: const TextStyle(
                      color: Colors.black54,
                      fontSize: 13,
                    ),
                  ),
                ),
              ],
            ),

            if ((_hasPublicUrl || _hasRemoteUrl) &&
                _normalizedMediaType == 'image')
              Padding(
                padding: const EdgeInsets.only(top: 12),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(16),
                  child: Image.network(
                    _bestRemoteUrl,
                    height: 190,
                    width: double.infinity,
                    fit: BoxFit.cover,
                    errorBuilder: (context, error, stackTrace) {
                      return Container(
                        height: 120,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          color: AppColors.background,
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: const Text('تعذر تحميل الصورة'),
                      );
                    },
                  ),
                ),
              ),
            if (!((_hasPublicUrl || _hasRemoteUrl) &&
                    _normalizedMediaType == 'image') &&
                _hasLocalImage)
              Padding(
                padding: const EdgeInsets.only(top: 12),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(16),
                  child: Image.file(
                    File(mediaPath!.trim()),
                    height: 190,
                    width: double.infinity,
                    fit: BoxFit.cover,
                    errorBuilder: (context, error, stackTrace) {
                      return Container(
                        height: 120,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          color: AppColors.background,
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: const Text('تعذر فتح الصورة المحلية'),
                      );
                    },
                  ),
                ),
              ),
            if (_hasRemoteVideo || _hasLocalVideo)
              Padding(
                padding: const EdgeInsets.only(top: 12),
                child: SizedBox(
                  width: double.infinity,
                  child: OutlinedButton.icon(
                    onPressed: () {
                      if (_resolvedSource.isEmpty) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            content: Text('لا يوجد مصدر صالح للفيديو'),
                          ),
                        );
                        return;
                      }

                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => VideoPreviewPage(
                            path: _resolvedSource,
                            mediaPath: mediaPath,
                            mediaUrl: mediaUrl,
                            publicUrl: publicUrl,
                            storageProvider:
                                (storageProvider ?? '').trim().isNotEmpty
                                    ? storageProvider
                                    : 'supabase',
                            title: 'فيديو ${type.trim().isEmpty ? 'التحديث' : type}',
                          ),
                        ),
                      );
                    },
                    icon: const Icon(Icons.play_circle_outline),
                    label: Text(
                      _hasRemoteVideo ? 'عرض الفيديو' : 'تشغيل الفيديو',
                    ),
                  ),
                ),
              ),
            if (kIsWeb && !_hasRemoteUrl && !_hasPublicUrl && _hasLocalPath)
              Padding(
                padding: const EdgeInsets.only(top: 12),
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.orange.withOpacity(0.10),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Text(
                    'تم حفظ مرفق محلي، لكن Flutter Web لا يعرض الملفات المحلية مباشرة.\nسيظهر المرفق عند نجاح رفعه كرابط.',
                    style: TextStyle(
                      color: Colors.orange,
                      height: 1.5,
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}